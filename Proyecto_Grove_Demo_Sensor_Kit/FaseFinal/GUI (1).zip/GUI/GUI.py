#Son las unicas librerias que se usan
#os ya viene por defecto, y pormite ejecutar comandos de consola, desde python.
#En este caso, esos comandos, son otroas scripts de python.
import os
import tkinter as tk
from tkinter import *


window = tk.Tk()
window.geometry("950x650")
window.title("Raspberry Demo GUI")

#Asi se crean los sensores, o mejor dicho, las variables booleanas que definen si un determinado sensor esta en funcionamiento.
#cuando se logren modificar estas, solo es necesario poner diferentes condiciones en el metodo paginaActividad() para indicar que
#los sensores de alguna actividad estan finalmente activos y correr el script determinado.
sensorLedBlue  = 0
sensorLedRed   = 0
sensorLedGreen = 0




def setElement(element,x,y):
    element.grid(row=x, column=y)

#Se crean distintas variables que almacenan la ruta a las imagenes usadas en la interdfaz grafica.
boton1 = PhotoImage(file="button1.gif")
boton2 = PhotoImage(file="button2.gif")
boton3 = PhotoImage(file="button3.gif")
boton4 = PhotoImage(file="button4.gif")
boton5 = PhotoImage(file="button5.gif")
ejecutarButton = PhotoImage(file="Ejecutar2.gif")
backButton = PhotoImage(file="back.gif")
photoPi =  PhotoImage(file="raspberry-pi-logo.gif")
photoUv =  PhotoImage(file="Logo-uv.gif")
photoBlank = PhotoImage(file="blank.gif")

#Para separar los botones, se crean unos "blanks" o espacios en blanco, que se ubican en los espacios de la rejilla que van entre los botones
#y son invisible.
blankSpace = 100
blank1 = Label(window,image=photoBlank, height=blankSpace, width=blankSpace)
blank3 = Label(window,image=photoBlank, height=blankSpace, width=blankSpace)
blank5 = Label(window,image=photoBlank, height=blankSpace, width=blankSpace)
blank7 = Label(window,image=photoBlank, height=blankSpace, width=blankSpace)
blank9 = Label(window,image=photoBlank, height=blankSpace, width=blankSpace)


#Se añaden tanto el logo de la universidad de valle como el logo de Raspberry PI
piLogo = Label(window,image=photoPi, height=200, width=240)
uvLogo = Label(window,image=photoUv, height=200, width=240)

#Se añaden los labels que contienen el etxto utilizado en la interfaz. Los labels son el titulo del protecto y el identificador de numero de la actividad.
titulo = Label(window,text="\nRaspberry PI Demo\nSensor Kit\n",fg="black",bg="white",font=("Arial",50))
numeroId = Label(window, text="test", fg="black", bg="white", font=("Arial", 60))



#Se crean todos los botones, llamando al metodo paginaActividad con un valor distinto, inicializando su tamaño y sus respectivas imagenes.
buttonSize = 142
btn1 = Button(window, image=boton1, height=buttonSize, width=buttonSize, borderwidth=0, command =lambda: paginaActividad(1))
btn2 = Button(window, image=boton2, height=buttonSize, width=buttonSize, borderwidth=0, command =lambda: paginaActividad(2))
btn3 = Button(window, image=boton3, height=buttonSize, width=buttonSize, borderwidth=0, command =lambda: paginaActividad(3))
btn4 = Button(window, image=boton4, height=buttonSize, width=buttonSize, borderwidth=0, command =lambda: paginaActividad(4))
btn5 = Button(window, image=boton5, height=buttonSize, width=buttonSize, borderwidth=0, command =lambda: paginaActividad(5))
back = Button(window, image=backButton, height=buttonSize, width=buttonSize, borderwidth=0, command =lambda: regresarPaginaPrincipal())

btnActividad1 = Button(window, image=ejecutarButton, height=buttonSize, width=buttonSize-1, borderwidth=0, command =lambda: ejecutarActividad(1))
btnActividad2 = Button(window, image=ejecutarButton, height=buttonSize, width=buttonSize-1, borderwidth=0, command =lambda: ejecutarActividad(2))
btnActividad3 = Button(window, image=ejecutarButton, height=buttonSize, width=buttonSize-1, borderwidth=0, command =lambda: ejecutarActividad(3))
btnActividad4 = Button(window, image=ejecutarButton, height=buttonSize, width=buttonSize-1, borderwidth=0, command =lambda: ejecutarActividad(4))
btnActividad5 = Button(window, image=ejecutarButton, height=buttonSize, width=buttonSize-1, borderwidth=0, command =lambda: ejecutarActividad(5))


#
# textoActividad1 = Label(window,text="\nRaspberry PI Demo\nSensor Kit\n",fg="black",bg="white",font=("Arial",50))
# textoActividad2 = Label(window,text="\nRaspberry PI Demo\nSensor Kit\n",fg="black",bg="white",font=("Arial",50))
# textoActividad3 = Label(window,text="\nRaspberry PI Demo\nSensor Kit\n",fg="black",bg="white",font=("Arial",50))
# textoActividad4 = Label(window,text="\nRaspberry PI Demo\nSensor Kit\n",fg="black",bg="white",font=("Arial",50))
# textoActividad5 = Label(window,text="\nRaspberry PI Demo\nSensor Kit\n",fg="black",bg="white",font=("Arial",50))


#En este metodo se escribi lo que debe ir en cada seccion de cada actividad. Esta dibuja sus contenido  de acuerto al boton
#que se haya presionado
def paginaActividad(numeroActividad):
    for btn in buttons:
        btn.grid_forget()
    back.grid(row=2, column = 0)
    numeroId.configure(text = "Actividad #"+str(numeroActividad))
    numeroId.grid(row =1, column = 1)
    if numeroActividad == 1:
        btnActividad1.grid(row=2, column=1)
    elif numeroActividad ==2:
        btnActividad2.grid(row=2, column=1)
    elif numeroActividad ==3:
        btnActividad3.grid(row=2, column=1)
    elif numeroActividad ==4:
        btnActividad4.grid(row=2, column=1)
    elif numeroActividad ==5:
        btnActividad5.grid(row=2, column=1)


def ejecutarActividad(numeroActividad):
    if numeroActividad == 1:
        os.system("python3 actividad1.py")
    elif numeroActividad == 2:
        os.system("python3 actividad2.py")
    elif numeroActividad == 3:
        os.system("python3 actividad3.py")
    elif numeroActividad == 4:
        os.system("python3 actividad4.py")
    elif numeroActividad == 5:
        os.system("python3 actividad5.py")

#Se crea una rreglo llamado buttons con todos los compenentes en la pantalla que seran escondidos luego de
#seleccionar una pestaña en espeficico
buttons = [btn1,btn2,btn3,btn4,btn5,blank1,blank3,blank5,blank7,blank9]

#Se crea el metodo regresar a la pantalla principal que se ejecuta luego de presionar su boton correspondiente u cuya funcion es
#dibujar nuevamente los componentes borrados.
def regresarPaginaPrincipal():
    numeroId.grid_forget()
    back.grid_forget()
    btnActividad1.grid_forget()
    btnActividad2.grid_forget()
    btnActividad3.grid_forget()
    btnActividad4.grid_forget()
    btnActividad5.grid_forget()

    titulo.grid(row=0, column=1, columnspan=3)
    piLogo.grid(row=0, column=0)
    uvLogo.grid(row=0, column=4)
    blank1.grid(row=1, column=0)
    blank1.grid(row=1, column=0)
    blank3.grid(row=1, column=2)
    blank5.grid(row=1, column=4)
    blank7.grid(row=2, column=1)
    blank9.grid(row=2, column=3)
    btn1.grid(row=1, column=1)
    btn2.grid(row=1, column=3)
    btn3.grid(row=2, column=0)
    btn4.grid(row=2, column=2)
    btn5.grid(row=2, column=4)








#Se añaden a la ventana los compenentes iniciales
titulo.grid(row = 0, column = 1,columnspan=3)

setElement(piLogo, 0, 0)
setElement(uvLogo, 0, 4)

setElement(blank1, 1, 0)
setElement(blank3, 1, 2)
setElement(blank5, 1, 4)
setElement(blank7, 2, 1)
setElement(blank9, 2, 3)
setElement(btn1, 1, 1)
setElement(btn2, 1, 3)
setElement(btn3, 2, 0)
setElement(btn4, 2, 2)
setElement(btn5, 2, 4)






#Finalmente se crea le ventana de la GUI
window.configure(background='white')
window.resizable(width=False, height=False)
window.mainloop()